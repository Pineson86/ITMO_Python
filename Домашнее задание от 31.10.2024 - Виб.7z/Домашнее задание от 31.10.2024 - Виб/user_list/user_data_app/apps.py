from django.apps import AppConfig


class UserDataAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'user_data_app'
